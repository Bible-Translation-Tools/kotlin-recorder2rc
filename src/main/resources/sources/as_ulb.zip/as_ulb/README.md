# Assamese ULB

## Prior to version 5

OT books from https://git.door43.org/BCS-BIBLE/ASSAMESE-ULB-OT.BCS with information from STR
https://git.door43.org/Door43/SourceTextRequestForm/issues/139

NT books are from https://git.door43.org/BCS-BIBLE/Assamese-ULB-NT.BCS/src/branch/master/Stage%203%20revised with information from STR
https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/150

## Version 5 and later

The updated books came in the form of Microsoft Word documents, converted to USFM. They include footnotes in the text.
