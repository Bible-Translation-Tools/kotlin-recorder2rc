# Alkitab Yang Terbuka (The 'Opened Bible') 
## Old Testament and New Testament

Note from joeg, 6-Jan-2018:

> AYT is a very Accurate (Faithful-Clear-Relevant) and Accountable translation.
> It is designed to be a trustable and study-able translation. I would equate it
> with your ULB+, and is somewhere around NET and ESV/HCSB/NIV, very not
> NASB/KJV. It can be used for serious study and yet is much more pleasant to
> read than the primary existing "Classic/Traditional/Formal" Indonesian
> translation (TB-1974), or the older previous version (TL-1950s).

> Source text - Greek , Hebrew, multiple Indonesian text