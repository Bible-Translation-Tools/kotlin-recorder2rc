# License
## Free Translate 2.0 International Public License

### Definitions

* **Licensed Material**: Alkitab Yang Terbuka (Opened Bible) Old Testament and New Testament

* **Licensor**: Yayasan Lembaga SABDA

* **Licensed Rights** means the rights granted to You subject to the terms and conditions of this Public License.

* **You** means any individual or entity now and in the future who exercises the rights granted under this Public License. **Your** has a corresponding meaning.


### Licensor grants You the right to:

  * **Translate** — non-exclusive, worldwide, royalty-free, non-sublicensable, irrevocable license to translate the licensed material, in whole or in part, into any different language(s).

### Under the following terms:

  * **Attribution** — You must attribute the source of the translation in a reasonable and noticeable manner, but not in any way that suggests the licensor endorses you or your use.


### Notices:

  * **Perpetual** — Licensor may not revoke this license as long as You comply with the license terms and conditions.

  * **Copyright of Translated Material** — The Licensor grants You ownership of all copyright and similar rights in your translations from the Licensed material, including the right to license Your translated workds (as long as it is done royalty free).

  * **No endorsement** — Nothing in this Public License constitutes or may be construed as permission to assert or imply that You are, or that Your use of the Licensed Material is connected with, sponsored, endorsed, or granted official status by, the Licensor.

  * **No trademarks** — Licensor's trademarks and Licensed Material's branding are not licensed under this Public License.

  * **No royalties** — To the fullest extent permitted by law and equity, Licensor waives any right to collect royalties from You for the exercise of the Licensed Rights, whether directly or through a collecting society under any voluntary or waivable statutory or compulsory licensing scheme.