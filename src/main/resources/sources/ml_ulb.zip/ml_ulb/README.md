# Malayalam ULB

STR https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/179 (OT), 
https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/189 (NT)

Mirror broken 20-May-2021.