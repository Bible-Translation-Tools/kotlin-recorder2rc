# Swahili ULB

STR for NT: https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/119

STR for OT: https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/208

Mirror broken 20-May-2021.
