# Laotian ULB

As of 26-Jan-2021, Proverbs 25.3 is missing.

Created WA-Catalog from PORT Publishing Request 2/1/21
