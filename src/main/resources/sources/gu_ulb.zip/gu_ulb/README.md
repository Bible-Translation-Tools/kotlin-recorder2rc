# Gujarati ULB

OT STR: https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/255

NT STR: https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/271

Mirror broken 20-May-2021.
