# Russian ULB

STR https://git.door43.org/Door43/SourceTextRequestForm/issues/148

Romans is incomplete, with 16:25-27 missing. The Russian Synodal Bible, a primary source text, also does not have Romans 16:25-27.

Many other verses are numbered differently than in English, particularly in the OT books of poetry. Many chapter divisions differ.

In addition, many verses in the Russian ULB (particularly OT poetry books and Matthew) have added content between square brackets, content that is not in the English ULB.

Mirror broken 20-May-2021.
