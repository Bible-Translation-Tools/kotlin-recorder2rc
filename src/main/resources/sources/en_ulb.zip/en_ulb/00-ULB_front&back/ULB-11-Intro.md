# Introduction to the Unlocked Literal Bible - English
The Unlocked Literal Bible (ULB)  is a relatively literal translation of the  Bible which translators may translate into their own language. It is intended to be used with other resources that help to clarify the meanings of words and phrases in the ULB or original languages. These resources also give suggestions about ways of expressing the meaning that translators might be able to use in their languages. These resources are Translation Words, Translation Notes, Translation Manual, Translation Questions, and the Unlocked Dynamic Bible (UDB).

  * **Translation Words** explain important terms that are repeated throughout the Bible.
  * **Translation Notes** explain complex theological terms and other translation issues. They also offer alternative translation suggestions.
  * **Translation Manual** explains different kinds of translation issues and provides strategies for dealing with them.
  * **Translation Questions** have questions and answers about the text. Translators can use these
      *  to test their own understanding of the ULB.
      *  to test their community's understanding of their translation to see if it is accurate and clear.
  * **The UDB** shows alternate ways of expressing the meaning in a more natural way. It also replaces many of the figures of speech in the ULB with plain language, and it makes some implicit information explicit.

The ULB and other resources are being translated from English into the world's Gateway Languages so that translators worldwide can use them as a set of resources for making accurate translations of God's Word in their own languages.

**You can learn more about the ULB** in the Appendix to the ULB [[rc://en_ulb/00-About_the_ULB/ULB-3-Appendix.md]]. It has the following sections: 
* Origin and Purpose of the ULB
* Notes about Making a "Relatively Literal" Translation
* Characteristics of the ULB
* Decisions Concerning the ULB
* Contributors to the ULB (Fuller list)

## Viewing
To read or print the ULB, see "Unlocked Literal Bible" on the "Translations" page of [Bible in Every Language](https://bibleineverylanguage.org/translations/) (https://bibleineverylanguage.org/translations/).

The Unlocked Literal Bible is also integrated into BTT Writer and VMAST so that translators can have  immediate access to it while translating. These tools are available on the Tools page of [Bible in Every Language](https://bibleineverylanguage.org/tools/) (https://bibleineverylanguage.org/tools/).

## Questions, comments, and suggestions
We welcome questions, comments, and suggestions. You may send them to helpdesk@techadvancement.com or training_wa@wycliffeassociates.org.

## Contributors to the ULB
  - James N. Pohlig, M.Div.; M.A. in Linguistics; D. Litt. in Biblical Languages
  - W. Thomas Warren, B.A. in Bible; M.Div.; D.Min
  - Larry Sallee, D.Min.
  - C. Harry Harriss, M.Div.
  - Hendrik "Henry" de Vries, M.Div.; Th.M.
  - Henry Whitney, B.A. in Education; Translator with Summer Institute of Linguistics, 1982-2001
  - John Hutchins, B.A.in Bible and Theology; M.A. in New Testament; M.A. in Biblical languages
  - Perry Oakes, MA in Linguistics; Ph.D in Old Testament 
  - Robert W. Johnson, B.S. and M.S. in Chemical Engineering
  - Susan R. Quigley, M.A. in Linguistics
  - Forest Deal
  - Door43 World Missions Community
  - Wycliffe Associates Staff