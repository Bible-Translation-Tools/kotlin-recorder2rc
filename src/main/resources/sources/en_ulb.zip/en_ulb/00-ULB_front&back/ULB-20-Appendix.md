# Appendix to the Unlocked Literal Bible

## Origin and Purpose of the English ULB

The English Unlocked Literal Bible (ULB) is an open-licensed version of the Bible derived from The American Standard Version, and updated using the most reliable Hebrew, Aramaic, and Greek copies of the Biblical texts available. It is intended to accurately reflect the meanings of those texts and to be used as a source text for Bible translators to translate the Bible into their own language.

Some might call the ULB "relatively literal" because it retains many of the grammatical structures, idioms, figures of speech, and semantically complex vocabulary used in the Hebrew, Aramaic, and Greek source documents. But when those grammatical structures, idioms, or figures of speech would be unintelligible or seriously misunderstood in English, the ULB minimally adjusts the grammatical structures and wording in order to express the same meanings in ways that are more clear in English.

The ULB is not meant to be a refined, polished English version. It is meant to present the meaning and structure of the original texts in so far as that can be done clearly and simply so that it can, in turn, be translated into other languages.

The ULB is intended to be used with other resources that help to clarify the meanings of words and phrases in the ULB or original languages. These resources also give suggestions about ways of expressing the meaning that translators might be able to use in their languages. These resources are Translation Words, Translation Notes, Translation Manual, Translation Questions, and the Unlocked Dynamic Bible (UDB).

  * **Translation Words** explain important terms that are repeated throughout the Bible.
  * **Translation Notes** explain complex theological terms and other translation issues. They also offer alternative translation suggestions.
  * **Translation Manual** explains different kinds of translation issues and provides strategies for dealing with them.
  * **Translation Questions** have questions and answers about the text. Translators can use these
      *  to test their own understanding of the ULB.
      *  to test their community's understanding of their translation to see if it is accurate and clear.
  * **The UDB** shows alternate ways of expressing the meaning in a more natural way. It also replaces many of the figures of speech in the ULB with plain language, and it makes some implicit information explicit.

## Notes About Making a "Relatively Literal" Translation
  * It is not possible to maintain a one-for-one correspondence between words in translation. One word from the source language may require a phrase for its translation in the target language, and vice-versa.
  * It is not possible to translate every word the same way every time it occurs and still have the correct meaning. Words need to be translated with the meaning that they have in their context, using whatever English word or phrase is closest to that meaning.
  * Both Greek and Hebrew can make a sentence without using a verb, while English cannot. For it to make sense in English, a verb needs to be supplied. (Usually the verb is "is").
  * Sometimes the grammatical structures of the original languages would be ungrammatical or easily misunderstood if used in English. In those cases other grammatical structures need to be used.
  * Greek makes abundant use of participial clauses. For the English to make sense, often these need to be changed to relative clauses or adverbial clauses.

## Characteristics of the Form of the English ULB
The English ULB translates the meaning of the original texts while seeking to use the language forms of those texts. The following statements describe what the English ULB tends to do as a relatively literal translation.
  * The ULB often reflects the grammatical structures that were used in the original language texts.
  * The ULB usually reflects the parts of speech that were used in the original language texts. For example, when the original text has an abstract noun, the ULB usually expresses the same idea with an abstract noun rather than with a verb or adjective.
  * The ULB translates many of the Hebrew and Greek technical terms related to religion and law with corresponding technical terms in English. Some examples are transgression, iniquity, redemption, gospel, and grace.
  * The ULB places clauses in the order that the original language texts placed them.
  * The ULB usually leaves implied what was left implied in the original language texts. If leaving the information implied will likely lead to confusion, the ULB makes the information explicit.
  * When expressions in the original language texts are ambiguous or unclear, the ULB often keeps the ambiguity or lack of clarity, instead of choosing a particular meaning.
  * The ULB sometimes uses names instead of pronouns, particularly at the beginning of chapters.

## Decisions Concerning the ULB
The following are decisions that have been made concerning the ULB. This is not a comprehensive list, but it is here to help those who might wonder why the ULB is as it is.

### ULB Style
The following are details concerning the use of punctuation, capitalization, and vocabulary in the ULB.

  * Titles are capitalized. (Son of Man, King David, the Messiah).
  * All pronouns, even those referring to God, are lower case (except when beginning sentences and except for the first singular "I").
  * Quotation marks are used at the beginning and ending of direct speech. They are not used at the beginning of each verse, even though the speech may span several verses.
  * Punctuation is normally (not always) inside the quotation marks. 
  * Contractions are not used in the ULB.
  * Where possible, the ULB editors have used common vocabulary that is easy to translate into another language.
  * Numbers are written as words if they have only one or two words ("three hundred," "thirty-five thousand"). Otherwise they are written as numerals. ("205," "1,005")

### Footnotes in the ULB
The ULB has footnotes for the following kinds of issues: 
* names that have multiple spellings
* people and places that have multiple names
* differences in Hebrew and Greek copies that lead to differences in modern versions
* alternative renderings of verses that are very hard to understand in the original languages
* differences between copies of the texts in the original languages and the early Greek and Latin translations

The footnotes use the following words in refering to copies and translations:  
* "Copies" refers to extant copies of the Biblical text, written in the original language, or to copies of the Septuagint or Vulgate.
* "Text" or "original text" refers to the Hebrew or Greek or Aramaic text compiled from all sources (that is, from all extant copies).
* "Translation" refers to ancient translations (the Septuagint and the Vulgate) and to modern translations.  

The ULB does not have footnotes for every textual issue, but it does address those that readers are most likely to encounter, particularly readers who have access to translations that were based on manuscripts known before the finding of the Dead Sea scrolls.

## Contributors to the ULB

{{manifest}}
