# Introduction to the Unlocked Literal Bible - English
The Unlocked Literal Bible (ULB) is intended to be used as a source text for Bible translators who may not have a reading knowledge of the original biblical languages. Some might call it "relatively literal" because it retains many of the grammatical structures, idioms, figures of speech, and semantically complex vocabulary used in the Hebrew, Aramaic, and Greek source documents. But when those grammatical structures, idioms, or figures of speech would be unintelligible or seriously misunderstood in English, the ULB minimally adjusts the grammatical structures and wording in order to express the same meanings in ways that are more clear in English.

The ULB is not meant to be a refined, polished English version. It is meant to present the meaning and structure of the original texts in so far as that can be done clearly and simply, so that it can, in turn, be translated into other languages.

The ULB is intended to be used with other resources that help to clarify the meanings of words and phrases in the ULB or original languages. These resources also give suggestions about ways of expressing the meaning that translators might be able to use in their languages. These resources are translationWords, translationNotes, Translation Manual, translationQuestions, and the Unlocked Dynamic Bible (UDB).

  * **translationWords** explain important terms that are repeated throughout the Bible.
  * **translationNotes** explain complex theological terms and other translation issues. They also offer alternative translation suggestions.
  * **Translation Manual** explains different kinds of translation issues and provides strategies for dealing with them.
  * **translationQuestions** have questions and answers about the text. Translators can use these
      *  to test their own understanding of the ULB.
      *  to test their community's understanding of their translation to see if it is accurate and clear.
  * **The UDB** shows alternate ways of expressing the meaning in a more natural way. It also replaces the figures of speech in the ULB with plain language, and it makes some implicit information explicit.

It is anticipated that the ULB and other resources will be translated from English into the world's Gateway Languages so that translators worldwide can use them as a set of resources for making accurate translations of God's Word in their own languages.
## Notes About Making a "Relatively Literal" Translation
  * It is not possible to maintain a one-for-one correspondence between words in translation. One word from the source language may require a phrase for its translation in the target language, and vice-versa.
  * It is not possible to translate every word the same way every time it occurs and still have the correct meaning. So the ULB seeks to translate words with the meaning that they have in their context, using whatever English word or phrase is closest to that meaning.
  * Both Greek and Hebrew can make a sentence without using a verb, while English cannot. For the ULB to make sense, the verb will always be supplied. (Usually the verb is "is").
  * Greek makes abundant use of participial clauses. For the English of the ULB to make sense, often these must be changed to relative or adverbial clauses.
  * In the ULB, the grammatical structures of the original languages are retained unless the English would be ungrammatical or easily misunderstood.
## The ULB Contrasted with the UDB
The ULB seeks to represent the language forms of the original in a way that also makes sense in English and other Gateway Languages. The UDB (Unlocked Dynamic Bible) seeks to represent the plain meaning of the original Bible text. Thus the ULB differs from the UDB in many ways. This means that:
  * The ULB reflects more than the UDB the grammatical structures of the biblical languages.
  * The ULB reflects more than the UDB the parts of speech of the biblical languages. The ULB, for example, seeks to use nouns where the original language uses nouns, adjectives where the original language uses adjectives, and so forth.
  * The ULB reflects the semantically complex vocabulary of the original languages more than the UDB does.
  * The ULB seeks to reproduce the form of the logical connections in the biblical languages. Thus, for example, the ULB has "the righteousness of faith" in Romans 4:13, and the logical relationship between righteousness and faith is not further specified. (Is it the righteousness that comes by faith? Is it the righteousness that vindicates faith?) All that "the righteousness of faith" explicitly signals is that there is some close association in the text between righteousness and faith, and that we can probably rule out a number of conceivable logical relationships between the two concepts, but not all possible relationships, as the foregoing example illustrates. In contrast, the UDB seeks to choose the most likely logical relationship. (Other likely logical relationships are sometimes presented in the translationNotes.)
  * The ULB usually reproduces the linear succession of ideas found in the original, even when English may prefer a different arrangement of the same ideas.
  * The ULB does  not normally present information that is only implied in the original. For example, in Matthew 26:5, "For they were saying, 'Not during the feast, so that a riot does not arise among the people.'" The implied information is, "Let us not arrest Jesus [during the feast]." The ULB does not overtly represent this implied information, while the UDB does.
  * The ULB reflects as much as reasonably possible the written style of the original. It has, for example, "Paul ... to Timothy..." instead of English's preferred, "Dear Timothy, this is Paul." The UDB has "I, Paul..., am writing this to Timothy."
  * The ULB departs from closely representing the structures of the original only when it must do so for the sake of clarity in English.
  * Even when the ULB is ambiguous or not entirely clear (as is often true of the original), the ULB must never promote to the translator the wrong meaning.
## Viewing
To read or print the ULB, see the ULB project on Bible in Every Language (https://door43.org/u/Door43/en_ulb/).

