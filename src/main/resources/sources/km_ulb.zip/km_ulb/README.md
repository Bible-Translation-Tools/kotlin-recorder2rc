# Khmer Bible (ULB)

Published by WA 29-March-2021