# French Louis Segond 1910 Bible (F10)

Resource container created from public domain, USFM source at http://ebible.org/find/details.php?id=fraLSG&all=1 

Mirror broken 20-May-2021
