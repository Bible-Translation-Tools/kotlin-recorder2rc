# Tamil ULB

Tamil OT files from https://git.door43.org/BCS-BIBLE/TAMIL-ULB-OT.BCS.

Tamil NT files from https://git.door43.org/BCS-BIBLE/Tamil-ULB-NT.BCS.

Mirror broken 20-May-2021.