# Ilocano ULB

https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/157 (OT) and
https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/156 (NT)

Mirror broken 20-May-2021
