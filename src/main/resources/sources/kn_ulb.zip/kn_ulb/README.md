# Kannada ULB

STR (OT): https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/256

NT files converted from https://git.door43.org/BCS-BIBLE/Kannada-ULB-NT.BCS Revised stage 3.

Mirror broken 20-May-2021.