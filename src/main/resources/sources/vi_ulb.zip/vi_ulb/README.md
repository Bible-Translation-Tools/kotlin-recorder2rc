# Vietnamese ULB.

STRs:
* https://git.door43.org/Door43/SourceTextRequestForm/issues/149
* https://git.door43.org/Door43/SourceTextRequestForm/issues/166
