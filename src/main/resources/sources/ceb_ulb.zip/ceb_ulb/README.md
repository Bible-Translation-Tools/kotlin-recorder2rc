# Cebuano ULB

STR https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/169

Books were translated from English ULB, version 4,5,6,7, or 8.

Mirror broken 20-May-2021.