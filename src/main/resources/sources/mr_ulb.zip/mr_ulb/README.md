# Marathi ULB text

STR https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/257 (OT)

STR https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/190 (NT)

Wycliffe Associates broke the 'mirror' of the DCS repo on 6-March-2021