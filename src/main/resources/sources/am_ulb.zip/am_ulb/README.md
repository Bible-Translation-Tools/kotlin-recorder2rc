# Amharic ULB

STRs:

* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/206 for OT
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/422 for NT

Migrated from https://git.door43.org/Door43-Catalog/am_ulb on 1/4/21 - cj