# Plateau Malagasy ULB

STRs:

* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/214 (NT)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/445 (OT)


Migrated from https://git.door43.org/Door43-Catalog/plt_ulb 1/5/20 cj