# Tagalog ULB

Conversion of Tagalog NT Level 3 translation uploaded by Ariel from July to 9 Aug 2017. 

STR https://git.door43.org/Door43/SourceTextRequestForm/issues/152  (OT), and https://git.door43.org/Door43/SourceTextRequestForm/issues/45  (NT)

Mirror broken 20-May-2021.