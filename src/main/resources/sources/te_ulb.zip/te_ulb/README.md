# Telugu ULB 

OT files from https://git.door43.org/BCS-BIBLE/TELUGU-ULB-OT.BCS

NT files are mostly from https://git.door43.org/BCS-BIBLE/Telugu-Revised-ULB-NT.BCS
but 1 John is from https://git.door43.org/BCS-BIBLE/Telugu-ULB-NT.BCS

Mirror broken 20-May-2021.