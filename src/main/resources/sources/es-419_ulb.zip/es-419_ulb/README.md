# Español Latino Americano ULB

* STR https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/324  (NT)
* STR https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/372  (OT)
* Jan 2022 updates at https://content.bibletranslationtools.org/Tech_Advance/es-419_ulb_PDF
* Mar 2022 updates at https://content.bibletranslationtools.org/Tech_Advance/es-419_ulb_PDF
