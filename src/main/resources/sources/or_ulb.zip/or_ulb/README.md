# Odiya / Odia / Oriya ULB

OT books from https://git.door43.org/BCS-BIBLE/ODIYA-ULB-OT.BCS/src/branch/master/Revised%20stage%203

NT books from https://git.door43.org/BCS-BIBLE/Odiya-ULB-NT.BCS/src/master/Revised%20stage%203

STR https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/213 and others

Mirror broken 20-May-2021.