# Punjabi ULB

STR (OT) https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/254

STR (NT) https://git.door43.org/Door43/SourceTextRequestForm/issues/138

Merged lists of contributors and checking entities from the 2016 (version 1) and 2018 (version 2) translations, although the lists had no overlap, and may have been done from separate source Bibles (1938 vs. 1945).

Mirror broken 20-May-2021.